# Project Name: Timereporting.NET

## Description
Timereporting.NET is a project built on the .NET framework that aims to provide a comprehensive time reporting solution. It follows a Domain-Driven Design (DDD) architecture, with decoupled and reusable C# components. The project includes both a web application and API integrations.

## 🚀 Installation
# Clone the repository
git clone https://github.com/mirasu-se/Timereporting.NET.git

# Navigate to the project directory
cd Timereporting.NET

# Place the Docker configuration files in the top-level directory
# Timereporting.NET

# Navigate to the web app project directory
cd Solution/Source/Presentation/Timereporting.Web

# Place the appsettings.{environment}.json files in the specified directory
# Timereporting.NET/Solution/Source/Presentation/Timereporting.Web


# Install Docker Desktop client and docker-compose from the official Docker website

💡 Usage

# Set the docker-compose project as the startup project in your Visual Studio interface
# Start all the required containers using docker-compose

# Navigate to the frontend directory
cd Timereporting.NET/Solution/Source/Presentation/Timereporting.UI/Frontend/Timereporting.Web

# Install the required dependencies
npm install

# Start the development server and bundle the files
npm run mvc-dev

# To perform file compression and minification for production
npm run mvc-build

# For additional info check package.json file

⚙️ Configuration
Place the appsettings.{environment}.json file in the directory: Timereporting.NET/Solution/Source/Presentation/Timereporting.Web

🔧 API Configuration
Local API:
Local API interface for testing with preconfigured Swagger UI can be accessed at: http://localhost:5000

Trinax API:
The project is preconfigured to work with the official Trinax API.

🤝 Contributing
If you encounter any issues during the setup of the development environment or have suggestions for improvements, feel free to reach out to me at milenko.raic@hotmial.com or via my public LinkedIn profile.

📝 License
This project is distributed under the MIT License. See the LICENSE file for more information.

📞 Contact
For any inquiries or support, please contact me at milenko.raic@hotmial.com or through my LinkedIn profile.

## 🏛️ Design and Architecture
- Domain Driven Design (CleanArch)
- Application Layer (CQRS implementation as a target)
- Domain Layer (Independent layer for all the business logic defined by stakeholders)
- Infrastructure Layer (Persistence with EF Core and code-first approach, all technical concerns)
- Interaction Layer (Layer with reusible DTOs and services related to interactiion between different system components)
- Presentation Layer (Layer related to UI technologies and shared UI libraries, separated from business concerns)

## 🙏 Acknowledgements
This project consists of various technologies, some of them include:

- Docker with Linux containers
- MySql database in Docker container (Check docker-compose.override.yml file)
- Entity Framework Core 
- MySql Entity Framework Core 
- Linq To SQL
- C# 
- JavaScript (ES6)
- jQuery
- Validation
- Ajax
- Bootstrap
- Sass
- Razor
- Automapper
- Asp NET Core Web App (MVC)
- Asp NET Core Web API (Defult project for storing images, CDN provider should be considered in the future)
- Rest API (Intergrated by trinaxApiClient.js and timereportingApiClient.js)
- API synchronization should be implemented in the future for all API requests


